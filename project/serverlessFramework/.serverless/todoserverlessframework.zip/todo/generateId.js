"use strict"

module.exports = () => (Math.random() * Math.pow(10,16)).toString();